package a_variable_ex;

public class VarEx2 {

	public static void main(String[] args) {

//		문제2
//		num1을 선언하고 이에 10을 할당하세요
//		num2을 선언하고 이에 20을 할당하세요
//		두 변수의 합을 구하고 그 결과를 새로운 변수 sum 에 저장하세요
//		최종적으로 sum 변수의 값을 출력하세요.
	
		int num1 = 10;
		int num2 = 20;
		
		int sum = num1 + num2;
		
		System.out.println("sum : " + sum);
		
	}

}
