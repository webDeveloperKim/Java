package array;

public class Array3 {

	public static void main(String[] args) {

//		배열의 생성과 초기화 방법 2가지 에시 입니다. 
		
//		생성자를 이용하여 값을 대입해주는 방법 
		int[] students_a = new int[] {90,80,70,60,50};
		
//		직접 배열로 값을 대입 시켜주는 방법 
		int[] students_b = {90,80,70,60,50};
		
		}
		
		
	}


