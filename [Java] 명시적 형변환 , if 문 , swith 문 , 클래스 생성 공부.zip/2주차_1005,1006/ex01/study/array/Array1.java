package array;

public class Array1 {

	public static void main(String[] args) {

//		배열이 필요한 이유
//		같은 데이터 타입의 변수를 편하게 사용하기 위헤서 하나로 묶기 위해서 사용 합니다.
		
//		아래는 배열을 사용하지 않고 int 타입의 변수를 선언 후 사용하는 예시 입니다.
		int student1 = 90;
		int student2 = 80;
		int student3 = 70;
		int student4 = 60;
		int student5 = 50;
		
		System.out.println("학생1 점수 : " + student1); 
		System.out.println("학생2 점수 : " + student2); 
		System.out.println("학생3 점수 : " + student3); 
		System.out.println("학생4 점수 : " + student4); 
		System.out.println("학생5 점수 : " + student5); 

	}

}
