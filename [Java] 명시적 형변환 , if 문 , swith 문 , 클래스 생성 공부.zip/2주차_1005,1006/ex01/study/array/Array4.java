package array;

public class Array4 {

	public static void main(String[] args) {

		//		2차원 배열 (2x3)
		/*
		 * ㅁㅁㅁ
		 * ㅁㅁㅁ
		 * 
		 */
		int[][] arr = new int[2][3];
		
		arr[0][0] = 1;
		arr[0][1] = 2;
		arr[0][2] = 2;

		arr[1][0] = 4;
		arr[1][1] = 5;
		arr[1][2] = 6;
		
		System.out.println(arr[0][0]);
		
		}
		
		
	}


