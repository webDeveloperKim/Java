package a_variable;

public class Hello {

	public static void main(String[] args) {

// 		자바 프로그램의 시작점 main 매서드
//		메서드 이름입니다.
//		역할: JVM이 프로그램 시작 시 가장 먼저 호출하는 특별한 이름입니다.
//		다른 이름으로는 사용할 수 없습니다.
		
//		String[] args
//		의미: 메서드 매개변수입니다.
//		역할: 명령줄에서 입력받은 값을 배열로 전달합니다.
		
		
//	모든 코드는 중괄호 {} 블록으로 감싸고 있음
//	outline 현재 작성중인 코드에 있는 구성요소의 계층화를 보여줍니다.

		
	}

}
