package operator;

public class Operator2 {

	public static void main(String[] args) {
//		문자열과 문자열 더하기
		String result1 = "hello" + "world";
		System.out.println(result1);
		
//		문자열에 숫자를 더하는 것은 문자열이 된다
		String s1 = "String1";
		int a = 10;
		System.out.println(s1 + 10);
		
	}

}
