package loop;

public class Loop {

	public static void main(String[] args) {
//		반복문을 쓰는 이유 == 변수를 쓰는 이유
		
		int sum = 0;
		
//		수정이 용이하지 않음
		
		sum = sum + 1;
		sum = sum + 2;
		sum = sum + 3;
		sum = sum + 4;
		sum = sum + 5;
		sum = sum + 6;
		
	}

}
