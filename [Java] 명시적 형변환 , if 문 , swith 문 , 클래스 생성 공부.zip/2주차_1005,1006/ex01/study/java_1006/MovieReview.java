package java_1006;

//	MovieReview 클래스 생성 
public class MovieReview {

	String title; // 영화 제목
	String review; // 영화 리뷰 내용
}
