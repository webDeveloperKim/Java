package java_1006;

public class Student {

//	class 키워드를 사용해서 학생 클래스 정의
//	class 는 관례 상 대문자로 시작하고 camel 표기
//	클래스는 초기값 설정 안해도 됨
//	멤버변수 ( =필드 ) 데이터 각각의 항목
	String name;
	int age;
	int grade;
}