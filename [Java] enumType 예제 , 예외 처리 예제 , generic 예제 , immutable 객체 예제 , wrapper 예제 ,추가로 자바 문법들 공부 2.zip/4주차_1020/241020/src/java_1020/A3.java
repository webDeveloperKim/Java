package java_1020;

public class A3 {

	public static void main(String[] args) {
		int[] arr = {1,2,3,4};
		
		int i = 0;
		
		while (i < arr.length) {
			System.out.println(arr[i]);
			i++;
		}

	}

}
