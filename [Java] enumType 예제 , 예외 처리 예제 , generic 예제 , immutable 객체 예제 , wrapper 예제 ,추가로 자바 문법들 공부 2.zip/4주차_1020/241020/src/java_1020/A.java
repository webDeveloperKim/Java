package java_1020;

public class A {

	public static void main(String[] args) {
		
		int num = 1;
		
		if(num == 1) {
			System.out.println("if블록");	
		}else if(num == 2) {
			System.out.println("elseif블록");
		}else {
			System.out.println("else 블록");
		}

	}

}
